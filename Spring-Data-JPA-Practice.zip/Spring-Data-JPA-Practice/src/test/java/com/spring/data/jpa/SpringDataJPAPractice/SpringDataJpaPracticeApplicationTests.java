package com.spring.data.jpa.SpringDataJPAPractice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataJpaPracticeApplicationTests {

	@Test
	void contextLoads() {
	}

}
